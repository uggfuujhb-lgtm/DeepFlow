export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');
  if (req.method === 'OPTIONS') { res.status(200).end(); return; }

  const path = req.query.path || '';
  const UW_KEY = process.env.UW_KEY || 'e82a2e15-8f40-4985-973a-4eeb9b7f7021';

  try {
    const url = `https://api.unusualwhales.com/api/${path}`;
    const r = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${UW_KEY}`,
        'Content-Type': 'application/json'
      }
    });
    const data = await r.json();
    res.status(r.status).json(data);
  } catch(e) {
    res.status(500).json({ error: e.message });
  }
}
