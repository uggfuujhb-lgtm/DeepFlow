export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS');
  if (req.method === 'OPTIONS') { res.status(200).end(); return; }

  const path = req.query.path || '';
  const MASS_KEY = process.env.MASS_KEY || '63icPsd_duqgWVPXMo6wgNVJ6McD69h4';

  try {
    const url = `https://api.massive.com/${path}`;
    const r = await fetch(url, {
      headers: { 'Authorization': `Bearer ${MASS_KEY}` }
    });
    const data = await r.json();
    res.status(r.status).json(data);
  } catch(e) {
    res.status(500).json({ error: e.message });
  }
}
